---
name: Intelligent Warmth
colors:
  surface: '#faf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#faf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f1'
  surface-container: '#efeeeb'
  surface-container-high: '#e9e8e5'
  surface-container-highest: '#e3e2e0'
  on-surface: '#1a1c1a'
  on-surface-variant: '#424845'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f2f1ee'
  outline: '#727975'
  outline-variant: '#c2c8c4'
  surface-tint: '#4a645b'
  primary: '#173028'
  on-primary: '#ffffff'
  primary-container: '#2d463e'
  on-primary-container: '#98b3a9'
  inverse-primary: '#b1cdc2'
  secondary: '#8a4f3b'
  on-secondary: '#ffffff'
  secondary-container: '#ffb198'
  on-secondary-container: '#7a412f'
  tertiary: '#302643'
  on-tertiary: '#ffffff'
  tertiary-container: '#463c5a'
  on-tertiary-container: '#b5a7cb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cce9dd'
  primary-fixed-dim: '#b1cdc2'
  on-primary-fixed: '#062019'
  on-primary-fixed-variant: '#334c44'
  secondary-fixed: '#ffdbd0'
  secondary-fixed-dim: '#ffb59d'
  on-secondary-fixed: '#370e02'
  on-secondary-fixed-variant: '#6e3826'
  tertiary-fixed: '#ebddff'
  tertiary-fixed-dim: '#cfc0e5'
  on-tertiary-fixed: '#201632'
  on-tertiary-fixed-variant: '#4c4260'
  background: '#faf9f6'
  on-background: '#1a1c1a'
  surface-variant: '#e3e2e0'
typography:
  headline-xl:
    fontFamily: Noto Serif
    fontSize: 40px
    fontWeight: '400'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '400'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 48px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style

This design system is anchored in the concept of "Intelligent Warmth," bridging the gap between high-performance AI utility and empathetic human support. The target audience is the modern woman seeking a digital sanctuary that organizes her life without adding cognitive load. 

The visual style is a refined **Minimalism** blended with **Soft Tactility**. It prioritizes heavy white space (using warm off-whites) to reduce anxiety and emphasizes "quality over quantity" in every interface element. The emotional response should be one of immediate decompression—a digital deep breath that feels sophisticated, intentional, and deeply reliable.

## Colors

The palette is designed to ground the user through nature-inspired tones. 
- **Primary (Deep Forest Green):** Used for primary actions, navigation, and grounding elements to signify stability and growth.
- **Secondary (Soft Terracotta):** Used for highlights, gentle calls-to-action, and progress indicators to provide a sense of organic warmth.
- **Tertiary (Muted Lavender):** Reserved for AI-driven insights, suggestions, and calm notifications, distinguishing machine intelligence with a soft, ethereal touch.
- **Background (Warm White):** A deliberate shift from stark digital white (#FFFFFF) to a paper-like warmth (#FAF9F6) to reduce eye strain and feel more tactile.

## Typography

This design system utilizes a sophisticated typographic pairing to balance editorial elegance with functional clarity. 

**Noto Serif** is the voice of the system’s "wisdom." It is used for headlines and reflective prompts, creating an atmosphere of a high-end journal or a trusted advisor. 

**Manrope** serves as the "engine." Its modern, geometric construction and high legibility make it ideal for task lists, calendar entries, and dense data. It feels professional yet approachable, ensuring that the "planning" aspect of the app remains clear and frictionless.

## Layout & Spacing

The layout follows a **Fluid Grid** model with generous margins to preserve the feeling of "breathable" space. 

- **Grid:** A 12-column grid for desktop and a 4-column grid for mobile.
- **Rhythm:** An 8px linear scale governs all padding and margins. 
- **Philosophy:** Components should never feel crowded. Use "stack-lg" (48px) between major sections to emphasize the minimalist aesthetic. Alignment should lean toward center-justified for reflective/onboarding screens and left-justified for active planning dashboards.

## Elevation & Depth

To maintain the "intelligent warmth" feel, avoid heavy drop shadows that feel dated. Instead, use **Tonal Layers** and **Ambient Shadows**.

- **Surfaces:** Use subtle shifts in background color (e.g., a slightly deeper cream) to differentiate cards from the main canvas.
- **Shadows:** When necessary to indicate interactivity, use very soft, diffused shadows with a slight tint of the Primary color (#2D463E) at 5-8% opacity. This makes the shadow feel like a natural part of the environment rather than a digital artifact.
- **Glassmorphism:** Use sparingly for AI-related overlays. A high-blur (20px-30px) backdrop filter with a white tint (10% opacity) creates a "frosted" look that feels premium and modern.

## Shapes

The shape language is organic and soft. Standard components use a **0.5rem (8px)** corner radius to feel approachable but professional. Larger containers, such as modal sheets or highlight cards, should use **1.5rem (24px)** to evoke the feel of a physical notebook or smooth pebble. Avoid sharp 90-degree angles entirely, as they create visual tension inconsistent with the brand.

## Components

- **Buttons:** Primary buttons use a solid Deep Forest Green with white Manrope text (Medium weight). Secondary buttons use an outline of Terracotta with a subtle cream fill on hover.
- **Cards:** Cards should have no borders. Use a soft 1-step tonal shift in background color and a 24px corner radius.
- **Inputs:** Text fields are underlined or use a very light-filled background rather than a full box, mimicking a physical planner. Focus states are indicated by a thickening of the bottom border in Terracotta.
- **Chips:** Used for categorizing tasks (e.g., "Work," "Self-Care"). These should be pill-shaped with low-saturation backgrounds derived from the primary and secondary colors.
- **Progress Indicators:** Use a "soft-fill" circular tracker. The stroke should be thin and elegant, using the Terracotta color to show completion.
- **AI "Pulse":** A unique component for this design system—a soft, animating gradient blur using the Muted Lavender, appearing behind AI-generated insights to signify the system is "thinking" or "supporting."
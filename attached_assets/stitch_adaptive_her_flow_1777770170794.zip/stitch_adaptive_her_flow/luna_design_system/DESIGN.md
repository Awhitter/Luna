---
name: Luna Design System
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e4e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#54433e'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0f0'
  outline: '#87736d'
  outline-variant: '#dac1ba'
  surface-tint: '#944931'
  primary: '#944931'
  on-primary: '#ffffff'
  primary-container: '#d67d61'
  on-primary-container: '#551905'
  inverse-primary: '#ffb59e'
  secondary: '#605e5b'
  on-secondary: '#ffffff'
  secondary-container: '#e6e2dd'
  on-secondary-container: '#666460'
  tertiary: '#56624b'
  on-tertiary: '#ffffff'
  tertiary-container: '#8c997f'
  on-tertiary-container: '#26311d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd0'
  primary-fixed-dim: '#ffb59e'
  on-primary-fixed: '#3a0b00'
  on-primary-fixed-variant: '#76321c'
  secondary-fixed: '#e6e2dd'
  secondary-fixed-dim: '#c9c6c1'
  on-secondary-fixed: '#1c1c19'
  on-secondary-fixed-variant: '#484743'
  tertiary-fixed: '#dae7ca'
  tertiary-fixed-dim: '#becbaf'
  on-tertiary-fixed: '#141e0d'
  on-tertiary-fixed-variant: '#3f4a35'
  background: '#fcf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e1'
typography:
  headline-xl:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '500'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-margin: 32px
  gutter: 24px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
This design system is built on the philosophy of "Digital Hospitality." It aims to dissolve the cold barrier between AI and user, replacing it with a nurturing, sophisticated environment that feels more like a living room than a software interface. The brand personality is supportive and intuitive, prioritizing emotional resonance over clinical efficiency.

The design style leans into **Minimalism with Tactile influences**. We leverage heavy whitespace and high-quality typography typical of modern minimalism, but ground the experience with organic grain textures and gentle, diffused shadows to create a sense of physical presence. The result is an interface that feels breathable, calm, and deeply human.

## Colors
The palette is inspired by natural materials—clay, linen, and dried botanicals—to evoke a sense of serenity.

- **Soft Terracotta (Primary):** Used for primary actions, active states, and brand-expressive moments. It provides warmth without the urgency of traditional reds.
- **Warm Cream (Secondary/Surface):** The foundation of the UI. It replaces harsh whites to reduce eye strain and provide a parchment-like comfort.
- **Dusty Sage (Tertiary):** A supportive hue used for success states, secondary accents, and categorized information that requires a calming presence.
- **Deep Charcoal (Text):** Used for high-contrast legibility. It is softened slightly from pure black to maintain the organic feel of the palette.

## Typography
The typographic pairing is central to the "Human-Centric" narrative. 

**Newsreader** is utilized for headlines to provide a literary, intellectual, and sophisticated feel. Its slight editorial weight makes the AI’s communications feel thoughtful and curated. 

**Plus Jakarta Sans** serves as the functional workhorse for the UI. Its soft, rounded terminals and open counters ensure the interface remains friendly and accessible. We use generous line-heights (1.6) for body text to improve readability and create a sense of unhurried pace.

## Layout & Spacing
The layout follows a **Fluid Grid** model with an emphasis on safe margins to maintain a "protected" feel for the content. We utilize a 12-column system for desktop and a 4-column system for mobile.

The spacing rhythm is intentionally generous. We avoid crowding elements to ensure the user never feels overwhelmed. Elements are grouped using a logical "Stack" system where related items are kept within 8-16px, while distinct sections are separated by 32px or more. Large margins (32px+) on the edges of containers help frame the content like a piece of art.

## Elevation & Depth
This design system uses **Ambient Shadows** and **Tonal Layers** to create hierarchy. 

- **Subtle Depth:** Shadows are never pure black; they are tinted with the Soft Terracotta or Deep Charcoal at very low opacities (5-8%). They feature large blur radii (20px+) to mimic soft, natural light hitting a matte surface.
- **Organic Texture:** A very fine, low-opacity noise/grain overlay (approx 3%) should be applied to the primary Cream background. This breaks the "digital perfection" and adds a tactile, paper-like quality.
- **Layering:** We use a "Surface-on-Surface" approach. Cards and containers sit slightly above the base background with a subtle shift in tone rather than a heavy shadow.

## Shapes
The shape language is characterized by "Soft Geometry." To reinforce the nurturing personality, sharp corners are strictly avoided.

All main containers and interactive components use a minimum radius of 16px (rounded-lg). Larger cards and modal overlays should scale up to 24px or 32px (rounded-xl) to emphasize a "cradling" effect. This high level of roundedness makes the interface feel approachable and safe to touch.

## Components
- **Buttons:** Primary buttons use the Soft Terracotta background with Deep Charcoal or White text. They should have a subtle 2px inner-glow on hover to simulate a physical button being illuminated.
- **Chips:** Used for suggestions or tags, these should have a Dusty Sage stroke or a very light Sage fill to distinguish them from primary actions without competing for attention.
- **Cards:** Cards are the primary vessel for information. They feature 24px padding and a 16px corner radius. The background is a slightly lighter version of the Cream base, separated by a 1px soft-terracotta border at 10% opacity.
- **Input Fields:** These should feel like a physical notepad. Use a subtle underline or a very soft-filled container with a rounded-md (8px) top and flat bottom, or a fully rounded container.
- **The Luna Presence:** A unique component—a floating, organic "orb" or shape using the Dusty Sage and Terracotta in a soft gradient, representing the AI's "listening" or "thinking" state with gentle, fluid animations.
- **Lists:** Items in a list should have generous vertical padding (16px) and be separated by soft, 1px cream-tinted dividers.